// JavaScript Document

$(document).ready(function(){
	$('#main-tabs').tabs();
	bindTabContextmenu();
	refreshMainIframe();
	$("body").bind('click',function(){
		$("#tab_rightmenu").addClass("hidden");
	});
});
$(window).resize(function() {
	refreshMainIframe();
});

/**
*打开菜单
*id 菜单标识
*label 菜单名称
*url 菜单URL
**/
function openMenu(id,label,url){
	MainTab.createTab(id,label,url);
	$(".sidebar-menu li").removeClass("active");
	if(id=='home'){
		$lis=$(".sidebar-menu").children();	
		for(var i=0;i<$lis.length-1;i++){
			var $li=$($lis[i]);
			if(!$li.hasClass("hidden")){
				$li.addClass("active");
				break;
			}
		}
	}else{
		$("#menu_"+id).addClass("active");
	}
}

/**
*切换系统
*systemid 系统标识
*systemname 系统名称
**/
function changeSystem(systemid,systemname,color){
	$("#sysname").text(systemname);
	var $swc=$("#swc_"+systemid);
	var clas=$swc.find("i").attr("class");
	var clasArray=clas.split(" ");
	var n_clas=clasArray[0]+" "+clasArray[1]+" write";
	$(".current-system").find("i").attr("class",n_clas);
	$(".dropdown-system-area .sitem").removeClass("active");
	$swc.addClass("active");
	
	$("#sidebar .sidebar-menu").children("li").addClass("hidden");
	$("#sidebar .sidebar-menu .static").removeClass("hidden");
	$("#sidebar .sys_"+systemid).removeClass("hidden");
	$(".navbar-inner").css("background",color);
	
	$($(".sidebar-menu .sys_"+systemid)[0]).removeClass("open");
	$($(".sidebar-menu .sys_"+systemid)[0]).addClass("open");

	setCookie("cookies_upms_system_id",systemid,365);

	
}
//切换一级菜单
function checkTopMenu(obj,systemid,topmenuid){
	$(".span_"+systemid).find(".menu-item").removeClass("checked");
	$(obj).addClass("checked");
	
	$("#sidebarid .system-group").addClass("hidden");
	$(".top_"+topmenuid).removeClass("hidden");
	
	var $ids=$("#sidebarid .span_"+systemid);
	for(var i=0;i<$ids.length;i++){
		if($($ids[i]).hasClass("static")){
			$($ids[i]).removeClass("hidden");
		}
	}
}



/**
*最大最小化TAB
**/
function maxminTab(){
	if($("#framework_body").length<=0){
		window.parent.maxminTab();
	}else{
		var $li=$("#framework_body").find("#main-tabs .ui-tabs-active");
		var id=$li.attr("id").split("_")[1];
		var ifm_id="ifm_"+id;
		if($("#"+ifm_id).hasClass("widget")){
			$("#"+ifm_id).removeClass("widget");
			$("#"+ifm_id).removeClass("maximized");
			$("#"+ifm_id).find(".widget-header").remove();
			
			var height=$(window).height()-90;
			$("#"+ifm_id).css("height",height);
			$("#"+ifm_id).find("iframe").css("height",height);
			
		}else{
			$("#"+ifm_id).addClass("widget");
			$("#"+ifm_id).addClass("maximized");
			var label=$li.find("a.ui-tabs-anchor").text();
			
			var html=  "<div class=\"widget-header bg-blue \">"+
							"<i class=\"widget-icon fa  fa-windows\"></i>"+
							"<span class=\"widget-caption\">"+label+"</span>"+
							"<div class=\"widget-buttons\">"+
								"<a href=\"javascript:maxminTab()\" ><i class=\"fa fa-minus\"></i></a>"+
							"</div>"+
						"</div>";
			$("#"+ifm_id).prepend(html);
			
			var height=$(window).height();
			$("#"+ifm_id).css({"height":height,"overflow":"no"});
			$("#"+ifm_id).find("iframe").css("height",height-41);
		}
	}
}

/**
*刷新当前TAB页面
**/
function refreshTabPage(){
	if($("#framework_body").length<=0){
		window.parent.refreshTabPage();
	}else{
		var $li=$("#framework_body").find("#main-tabs .ui-tabs-active");
		var id=$li.attr("id").split("_")[1];
		var ifm_id="ifm_"+id;
		var src=$("#"+ifm_id).find("iframe").attr("src");
		$("#"+ifm_id).find("iframe").attr("scr",src);
	}

}


/**
*右键菜单关闭TAB页
**/
function menuCloseTab(tag){
	var $lis=$("#main-tabs li");
	var $thisli;
	var index=0;
	var length=$lis.length;
	for(var i=0;i<$lis.length;i++){
		var $li=$($lis[i]);
		if($li.attr("aria-selected")=="true"){
			$thisli=$li;
			index=i;
			break;
		}
	}
	
	if(tag=='this'){
		if(index!=0){
			var panelId=$thisli.remove().attr( "aria-controls" );
			$( "#" + panelId ).remove();
			$('#main-tabs').tabs( "refresh" );
		}else{
			Notify('首页标签不可关闭!', 'top-right', '5000', 'danger', 'fa-bolt', true);
		}
	}else if(tag=='all'){
		for(var i=1;i<length;i++){
			var $li=$($lis[i]);
			var panelId=$li.remove().attr( "aria-controls" );
			$( "#" + panelId ).remove();
		}
		$('#main-tabs').tabs( "refresh" );
	}else if(tag=='other'){
		for(var i=1;i<length;i++){
			if(i!=index){
				var $li=$($lis[i]);
				var panelId=$li.remove().attr( "aria-controls" );
				$( "#" + panelId ).remove();
			}
		}
		$('#main-tabs').tabs( "refresh" );
		
	}else if(tag=='left'){
		for(var i=1;i<index;i++){
			var $li=$($lis[i]);
			var panelId=$li.remove().attr( "aria-controls" );
			$( "#" + panelId ).remove();
		}
		$('#main-tabs').tabs( "refresh" );
		
	}else if(tag=='right'){
		for(var i=index+1;i<length;i++){
			var $li=$($lis[i]);
			var panelId=$li.remove().attr( "aria-controls" );
			$( "#" + panelId ).remove();
		}
		$('#main-tabs').tabs( "refresh" );
	}
	
}
